export * from "./dist/secure-qr-scanner.es.js";
